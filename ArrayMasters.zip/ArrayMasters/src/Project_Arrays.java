

import java.util.Scanner;

public class Project_Arrays {
	static Operations obj = new Operations();
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter array size which is greater than -1 : ");
		int size = sc.nextInt();
		int a[] = new int[size];
		for (int i = 0; i < a.length; i++) {
			System.out.println("Enter the " + (i + 1) + " position element : ");
			a[i] = sc.nextInt();
		}
		boolean flag = true;
		while (flag) {
			System.out.println(" 1.insert \n 2.insertAll \n 3.delete \n 4.deleteAll \n 5.update "
					+ "\n 6.updateAll \n 7.ocuurance \n 8.firstOccurance \n 9.LastOccurance \n 10.sort "
					+ "\n 11.reverse \n 12.min \n 13.max \n 14.sum \n 15.avg "
					+ "\n 16.display \n 17.clear \n 18.isEmpty \n 19.Exit");
			System.out.println();
			System.out.println("Select an option from the above options........");
			int option = sc.nextInt();
			if (option > 19 || option < 1)
				System.out.println("\n Invalid operation selected \n \n TRYAGAIN...!!!!\n \n");
			else {
				switch (option) {
				case 1: {
					System.out.println("Enter the new element to insert");
					int ele = sc.nextInt();
					System.out.println("Enter the position");
					int pos = sc.nextInt();
					a = obj.insert(a, ele, pos);
					obj.display(a);
					break;
				}
				case 2: {
					System.out.println("Enter how many elements you want to insert : ");
					int s = sc.nextInt();
					int b[] = new int[s];
					for (int i = 0; i < b.length; i++) {
						System.out.println("Enter the " + (i + 1) + " position element : ");
						b[i] = sc.nextInt();
					}
					a = obj.merge(a, b);
					obj.display(a);
					break;
				}
				case 3: {
					System.out.println("Enter the element  to delete : ");
					int element = sc.nextInt();
					int index = obj.firstOccur(a, element);
					a = obj.delete(a, index);
					obj.display(a);
					break;
				}
				case 4: {
					a = new int[0];
					obj.display(a);
					break;
				}
				case 5: {
					System.out.println("Enter the new element : ");
					int element = sc.nextInt();
					System.out.println("Enter the position : ");
					int pos = sc.nextInt();
					a = obj.update(a, element, pos);
					obj.display(a);
					break;
				}
				case 6: {
					for (int i = 0; i < a.length; i++) {
						System.out.println("Enter the " + (i + 1) + " index element : ");
						a[i] = sc.nextInt();
					}
					obj.display(a);
					break;
				}
				case 7: {
					System.out.println("Enter the element you want to count : ");
					int element = sc.nextInt();
					int count = obj.occur(a, element);
					if (count > 0)
						System.out.println("The count the given element is " + count);
					else
						System.out.println("No such element found...!!");
					obj.display(a);
					break;
				}
				case 8: {
					System.out.println("Enter the element you want to count at the first occurance : ");
					int element = sc.nextInt();
					int count = obj.firstOccur(a, element);
					if (count > 0)
						System.out.println("The first occurance was at " + count);
					else
						System.out.println("No such element found...!!");
					obj.display(a);
					break;
				}
				case 9: {
					System.out.println("Enter the element you want to count at the last occurance : ");
					int element = sc.nextInt();
					int count = obj.lastOccur(a, element);
					if (count > 0)
						System.out.println("The last occurance was at " + count);
					else
						System.out.println("No such element found...!!");
					obj.display(a);
					break;
				}
				case 10: {
					a = obj.sort(a);
					obj.display(a);
					break;
				}
				case 11: {
					obj.reverse(a);
					obj.display(a);
					break;
				}
				case 12: {
					int min = obj.min(a);
					System.out.println(min);
					obj.display(a);
					break;
				}
				case 13: {
					int max = obj.max(a);
					System.out.println(max);
					obj.display(a);
					break;
				}
				case 14: {
					int sum = obj.sum(a);
					System.out.println(sum);
					obj.display(a);
					break;
				}
				case 15: {
					int avg = obj.avg(a);
					System.out.println(avg);
					obj.display(a);
					break;
				}
				case 16: {
					obj.display(a);
					break;
				}
				case 17: {
					obj.isEmptyt(a);
					obj.display(a);
					break;
				}
				case 18: {
					obj.isEmptyt(a);
					obj.display(a);
					break;
				}
				case 19: {
					flag = false;
					break;
				}
				}
			}
		}
	}
}
