

import java.util.Arrays;

public class Operations {

	public int firstOccur(int a[], int ele) {
		for (int i = 0; i < a.length; i++) {
			if (a[i] == ele)
				return i;
		}
		return -1;
	}

	public int lastOccur(int a[], int ele) {
		int l = -1;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == ele)
				l = i;
		}
		return l;
	}

	public int occur(int a[], int ele) {
		int c = 0;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == ele)
				c++;
		}
		return c;
	}

	public int[] merge(int a[], int b[]) {
		int c[] = new int[a.length + b.length];
		for (int i = 0; i < c.length; i++) {
			if (i < a.length)
				c[i] = a[i];
			else
				c[i] = b[i - a.length];
		}
		return c;
	}

	public void reverse(int a[]) {
		for (int i = 0, j = a.length - 1; i < a.length / 2; i++, j--) {
			int temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	}

	public int min(int a[]) {
		int min = a[0];
		for (int i : a) {
			if (i < min)
				min = i;
		}
		return min;
	}

	public int max(int a[]) {
		int max = a[0];
		for (int i : a) {
			if (i > max)
				max = i;
		}
		return max;
	}

	public int sum(int a[]) {
		int sum = 0;
		for (int i : a)
			sum += i;
		return sum;
	}

	public int avg(int a[]) {
		int sum = 0;
		for (int i : a)
			sum += i;
		return sum / a.length;
	}

	public int[] isEmptyt(int a[]) {
		return new int[0];
	}

	public void display(int arr[]) {
		System.out.println(Arrays.toString(arr));
	}

	public int[] sort(int a[]) {
		for (int i = 0; i < a.length-1; i++) {
			for (int j = 0; j < a.length-1; j++) {
				if(a[j]>a[j+1]) {
					int c=a[j];
					a[j]=a[j+1];
					a[j+1]=c;
				}
			}
		}
		return a;
	}

	public int[] insert(int arr[], int element, int pos) {
		if (pos > arr.length + 1 || pos < 1)
			System.out.println("Insertion is not possible");
		else {
			int b[] = new int[arr.length + 1];
			for (int i = 0, j = 0; i < b.length; i++) {
				if (i == pos - 1)
					b[i] = element;
				else
					b[i] = arr[j++];
			}
			return b;
		}
		return arr;
	}

	public int[] delete(int a[],int index) {
		int b[] = new int[a.length - 1];
		if (a.length == 0)
			System.out.println("Array is empty.");
		else if (index == -1)
			System.out.println("Deleting element is not present.");
		else {
			int j = 0;
			for (int i = 0; i < a.length; i++) {
				if (i != index)
					b[j++] = a[i];
			}
		}
		return b;
	}
	
	public int[] update(int arr[],int element ,int pos) {
		for (int i = 0; i < arr.length; i++) {
			if (i == pos - 1)
				arr[i] = element;
		}
		return arr;
	}

	
}